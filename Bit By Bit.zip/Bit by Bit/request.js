document.getElementById("user-name").textContent = "John Doe"; 
document.getElementById("user-full-name").textContent = "John Doe"; 
document.getElementById("user-email").textContent = "johndoe@example.com"; 
document.getElementById("payment-method").textContent = "PayPal"; 
document.getElementById("payment-info").textContent = "johndoe@paypal.com";
