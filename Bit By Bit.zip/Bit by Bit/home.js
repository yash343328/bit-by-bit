// Smooth Scroll for Navigation Links
document.addEventListener("DOMContentLoaded", function () {
    // Get all the navigation links
    const navLinks = document.querySelectorAll('nav ul li a');

    // Add event listener for each link
    navLinks.forEach(link => {
        link.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent default link behavior

            // Get the target section based on the href attribute
            const targetId = this.getAttribute('href').substring(1); // Remove the '#' symbol
            const targetSection = document.getElementById(targetId);

            if (targetSection) {
                // Smoothly scroll to the target section
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start', // Aligns the section at the top of the viewport
                });
            }
        });
    });
});
