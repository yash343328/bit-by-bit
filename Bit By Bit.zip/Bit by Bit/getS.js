document.getElementById('paymentForm').addEventListener('submit', function(event){
    event.preventDefault();
});